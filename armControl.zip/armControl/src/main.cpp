/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\99772702                                         */
/*    Created:      Thu Oct 20 2022                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Drivetrain           drivetrain    10, 1           
// armMotor             motor         5               
// claw                 motor         2               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  armMotor.setStopping(hold);
  armMotor.setTimeout(5, seconds);
  armMotor.spinToPosition(180, degrees);
  wait(2, seconds);
  armMotor.spinToPosition(480, degrees);

}
